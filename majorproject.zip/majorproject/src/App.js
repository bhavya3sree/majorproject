import React from 'react';
import LandingPage from './components/LandingPage';
import RequestPricingPage from './components/RequestPricingPage';
import BlogPage from './components/BlogPage';
import AboutUs from './components/AboutUs';



import './App.css'; // Import the main CSS file

const App = () => {
  return (
    <div>
      <LandingPage />
      <RequestPricingPage />
      <BlogPage />
      <AboutUs />
    </div>
  );
};

export default App;
