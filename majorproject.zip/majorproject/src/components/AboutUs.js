import React from 'react';
import '../styles/AboutUs.css';
import client1 from './images/client1.jpeg';
import client2 from './images/client2.jpeg';
const AboutUs = () => {
  return (
    <div className="blog-container">
      <section className="introduction-section">
        <h2><u><i>AboutUs</i></u></h2>
        <h2>Introduction</h2>
        <p>
          Welcome to our government's digital services blog! Here, we share insights, updates,
          and stories about our journey in the digital transformation space.
        </p>
        <p>
          Our mission is to contribute to the digitalization of businesses by providing
          top-notch services in Digital Marketing, Website Development, Graphic Designing, and more.
        </p>
      </section>

      <section className="team-members-section">
        <h2>Team Members</h2>
        <div className="team-member">
          <img src={client1} alt="Team Member 1" />
          <p>
            <strong>John Doe</strong>
            <br />
            Digital Marketing Specialist
          </p>
        </div>
        <div className="team-member">
          <img src={client2} alt="Team Member 2" />
          <p>
            <strong>Jane Smith</strong>
            <br />
            Website Development Lead
          </p>
        </div>
        {/* Add more team members as needed */}
      </section>

      <section className="faq-section">
        <h2>Frequently Asked Questions</h2>
        <div className="faq-item">
          <h3>What services do you offer?</h3>
          <p>
            We offer a range of digital services, including Digital Marketing, Website
            Development, Graphic Designing, and more. Explore our Services page for detailed
            information.
          </p>
        </div>
        <div className="faq-item">
          <h3>How can I contact you for services?</h3>
          <p>
            You can visit our Contact Us page to get in touch with our team. We'd be happy to
            discuss your digital needs and provide tailored solutions.
          </p>
        </div>
        <div className="faq-item">
          <h3>What services do you offer?</h3>
          <p>
            We offer a range of digital services, including Digital Marketing, Website
            Development, Graphic Designing, and more. Explore our Services page for detailed
            information.
          </p>
        </div>
        <div className="faq-item">
          <h3>What services do you offer?</h3>
          <p>
            We offer a range of digital services, including Digital Marketing, Website
            Development, Graphic Designing, and more. Explore our Services page for detailed
            information.
          </p>
        </div>
        {/* Add more FAQ items as needed */}
      </section>
    </div>
  );
};

export default AboutUs;
