import React, { useState, useEffect } from 'react';
import '../styles/BlogPage.css';

const BlogPage = () => {
  const [blogPosts, setBlogPosts] = useState([]);

  useEffect(() => {
    // Mock API endpoint for blog posts
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts';

    // Fetch blog posts from the API
    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => setBlogPosts(data.slice(0, 5))); // Limit to the first 5 posts for demonstration
  }, []);

  return (
    <div className="blog-container">
      <h2>Latest Blog Posts</h2>
      {blogPosts.map((post) => (
        <div key={post.id} className="blog-post">
          <h3>{post.title}</h3>
          <p>{post.body}</p>
          <a href={`#blog/${post.id}`}>Read more</a>
        </div>
      ))}
    </div>
  );
};

export default BlogPage;
