import react from 'react';
import '../styles/LandingPage.css';

import benefits1 from './images/benifits1.jpg';
import benefits2 from './images/benifits2.jpg';
import benefits3 from './images/benifits3.jpg';
import digital from './images/digital.jpg';
import web from './images/web.jpg';
import graphic from './images/graphic.jpg';
import client1 from './images/client1.jpeg';
import client2 from './images/client2.jpeg';
import cli from './images/cli.jpeg';
import client3 from './images/client3.jpeg';
import ServicesPage from '../components/ServicePages';
import ContactForm from '../components/ContactForm';
const LandingPage = () => {
  const [showServices, setShowServices] = react.useState(false);
  const [showContact, setShowContact] = react.useState(false);

  const handleServicesClick = () => {
    setShowServices(true);
    setShowContact(false);
  };

  const handleContactClick = () => {
    setShowServices(false);
    setShowContact(true);
  };

  return (
    <div className="landing-page">
      {/* Overview Section */}
      <section className="overview-section">
        <div className="intro-container">
          <h1>Welcome to Government Digital Services</h1>
          <p>
            Empowering businesses through cutting-edge digital solutions. Explore our services and
            accelerate your journey to success.
          </p>
        </div>

        <div className="carousel-container">
          {/* Placeholder Carousel Images */}
        <img src={benefits1} alt="corouselimage 1" />
          <img src={benefits2} alt="Carousel Image 2" />
          <img src={benefits3} alt="Carousel Image 3" />
        </div>
      </section>

      {/* Services Section */}
      <section className="services-section">
        <h2>Our Services</h2>
        <div className="services-container">
          {/* Service Card 1 */}
          <div className="service-card">
            <img src={digital} alt="Service Icon 1" />
            <h3>Digital Marketing</h3>
            <p>Strategic digital campaigns to boost your brand presence.</p>
          </div>

          {/* Service Card 2 */}
          <div className="service-card">
            <img src={web} alt="Service Icon 2" />
            <h3>Website Development</h3>
            <p>Custom websites tailored to meet your business needs.</p>
          </div>

          {/* Service Card 3 */}
          <div className="service-card">
            <img src={graphic} alt="Service Icon 3" />
            <h3>Graphic Designing</h3>
            <p>Eye-catching visuals that leave a lasting impression.</p>
          </div>
        </div>
      </section>

      {/* Call to Action (CTA) */}
      <section className="cta-section">
        <h2>Ready to Transform Your Business?</h2>
        <p>Explore our services or contact us for more information.</p>
        <div className="cta-buttons">
        <div>
      {/* Landing page content */}
      <button onClick={handleServicesClick}>Explore Services</button>
      <button onClick={handleContactClick}>Contact Us</button>

      {/* Conditional rendering based on button click */}
      {showServices && <ServicesPage />}
      {showContact && <ContactForm />}
    </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials-section">
        <h2>What Our Clients Say</h2>
        <div className="testimonial-container">
          {/* Testimonial 1 */}
          <div className="testimonial">
            <img src={client1} alt="Client Logo 1" />
            <p>
              "Government Digital Services has truly revolutionized our online presence. Their
              expertise and dedication are commendable."
            </p>
            <p className="client-name">John Doe, XYZ Company</p>
          </div>

          {/* Testimonial 2 */}
          <div className="testimonial">
            <img src={client2} alt="Client Logo 2" />
            <p>
              "The digital solutions provided by the government have significantly impacted our
              business growth. Highly recommended!"
            </p>
            <p className="client-name">Jane Smith, ABC Corporation</p>
          </div>
          <div className="testimonial">
            <img src={cli} alt="Client Logo 2" />
            <p>
              "The digital solutions provided by the government have significantly impacted our
              business growth. Highly recommended!"
            </p>
            <p className="client-name">senorita, NGO Corporation</p>
          </div>
          <div className="testimonial">
            <img src={client3} alt="Client Logo 2" />
            <p>
              "The digital solutions provided by the government have significantly impacted our
              business growth. Highly recommended!"
            </p>
            <p className="client-name">gnana, gp Corporation</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
