import React, { useState } from 'react';
import '../styles/RequestPricingPage.css';

const RequestPricingPage = () => {
  const [formData, setFormData] = useState({
    serviceName: '',
    budget: '',
    projectDetails: '',
    contactInfo: '',
  });
  const [confirmation, setConfirmation] = useState(false);

  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    
    setConfirmation(true);
    setFormData({
      serviceName: '',
      budget: '',
      projectDetails: '',
      contactInfo: '',
    });
  };

  return (
    <div className="request-pricing-container">
      <h2>Quote Form</h2>
      {confirmation ? (
        <div className="confirmation-message">
          Thank you for your quote request! We will get back to you soon.
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="serviceName">Service Name:</label>
            <input
              type="text"
              id="serviceName"
              name="serviceName"
              value={formData.serviceName}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="budget">Budget:</label>
            <input
              type="text"
              id="budget"
              name="budget"
              value={formData.budget}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="projectDetails">Project Details:</label>
            <textarea
              id="projectDetails"
              name="projectDetails"
              value={formData.projectDetails}
              onChange={handleInputChange}
              required
            ></textarea>
          </div>
          <div className="form-group">
            <label htmlFor="contactInfo">Contact Information:</label>
            <input
              type="text"
              id="contactInfo"
              name="contactInfo"
              value={formData.contactInfo}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <button type="submit">Submit Request</button>
          </div>
        </form>
      )}
    </div>
  );
};

export default RequestPricingPage;
