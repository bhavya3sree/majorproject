import React from 'react';
import '../styles/ServicesPage.css';

// Import necessary images or icons for each service
import digital from './images/digital.jpg';
import web from './images/web.jpg';
import graphic from './images/graphic.jpg';

const ServicesPage = () => {
  return (
    <div className="services-page">
      <div className="service-section">
        <div className="service-header">
          <img src={digital} alt="Digital Marketing Icon" />
          <h2>Digital Marketing</h2>
        </div>
        <div className="service-content">
          {/* Include detailed information about Digital Marketing */}
          <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <p>Features: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <p>Benefits: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          {/* Add visuals, carousels, and icons as needed */}
        </div>
        <div className="cta-button">
          <button>Request More Information</button>
        </div>
      </div>

      <div className="service-section">
        <div className="service-header">
          <img src={web} alt="Website Development Icon" />
          <h2>Website Development</h2>
        </div>
        <div className="service-content">
          {/* Include detailed information about Website Development */}
          <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <p>Features: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <p>Benefits: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          {/* Add visuals, carousels, and icons as needed */}
        </div>
        <div className="cta-button">
          <button>Request More Information</button>
        </div>
      </div>

      <div className="service-section">
        <div className="service-header">
          <img src={graphic} alt="Graphic Designing Icon" />
          <h2>Graphic Designing</h2>
        </div>
        <div className="service-content">
          {/* Include detailed information about Graphic Designing */}
          <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <p>Features: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          <p>Benefits: Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p>
          {/* Add visuals, carousels, and icons as needed */}
        </div>
        <div className="cta-button">
          <button>Request More Information</button>
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;
